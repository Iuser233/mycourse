package seqlist;

public class student {
private String name;
	

private int age;


public student(String name, int age) {
	super();
	this.name = name;
	this.age = age;
}


@Override
public String toString() {
	return "student [name=" + name + ", age=" + age + "]";
}
	


}
